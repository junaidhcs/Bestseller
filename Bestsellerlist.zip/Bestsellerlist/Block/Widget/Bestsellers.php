<?php

namespace Storepro\BestSellerlist\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\Product;
use Magento\Framework\ObjectManagerInterface;

class Bestsellers extends Template implements BlockInterface
{
    protected $_template = "widget/bestsellers.phtml";

    protected $_helperImage;
    
    protected $_objectManager;

    public function __construct(
        Template\Context $context,
        \Magento\Sales\Model\ResourceModel\Report\Bestsellers\CollectionFactory $bestSellersCollectionFactory,
        Image $helperImage,
        ObjectManagerInterface $objectManager,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->setData('area', 'frontend');
        $this->bestSellersCollectionFactory = $bestSellersCollectionFactory;
        $this->_helperImage = $helperImage;
        $this->_objectManager = $objectManager;
    }

    /**
     * Get best selling products collection
     *
     * @return \Magento\Sales\Model\ResourceModel\Report\Bestsellers\Collection
     */
    public function getBestSellers()
    {
        $collection = $this->bestSellersCollectionFactory->create();
        $collection->setPageSize($this->getData('products_count'));
        return $collection;
    }
    public function getProductImage($productId)
    {
        $product = $this->_objectManager->create(Product::class)->load($productId);
        $productImg = $this->_helperImage->init($product, 'small_image')->setImageFile($product->getSmallImage())->resize(300, 300)->getUrl();

        if (empty($productImg) || $productImg == 'no_selection') {
            $productImg = $this->getViewFileUrl('Magento_Catalog::images/product/placeholder/small_image.jpg');
            $altTag = "no image item";
        } else {
            $productImg = $this->_helperImage->init($product, 'small_image')->setImageFile($product->getSmallImage())->resize(300, 300)->getUrl();
            $altTag = $product->getName();
        }

        return ['imgUrl' => $productImg, 'altTag' => $altTag];
    }
}
